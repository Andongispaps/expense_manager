<!-- scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.0/noframework.waypoints.min.js"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>

{{-- Al Jhune jQuery cdn --}}
<script src="{{ asset('resources/views/plugins/jQuery/jquery-3.5.1.min.js') }}"></script>

<script type="text/javascript" src="{{  asset('resources/views/plugins/bootstrap/bootstrap.bundle.min.js')  }}"></script>
<script type="text/javascript" src="{{  asset('resources/views/plugins/misc/swiper-bundle.min.js')  }}"></script>

{{-- For Role Module --}}
<script>
    $(document).ready(function() {
        $('.editrolemodal').click(function() {
            var jerome = $(this).attr('data-roleid');

            $.ajax({
                url: "{{ URL::to('/editRole') }}",
                method: "POST",
                data: {
                    role_id: jerome,
                    _token: '{{ csrf_token() }}'
                },
                success: function(data) {
                    $('.updaterolecontent').html(data);
                    $('#updaterolemodal').modal('show');
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#updateroledata').click(function() {
            var name = $('input[name="name"]').val();
            var description = $('input[name="description"]').val();
            var jerome = $('input[name="role_id"]').val();

            $.ajax({
                url: "{{ URL::to('/updateRole') }}",
                method: "POST",
                data: {
                    role_id: jerome,
                    name: name,
                    description: description,
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {
                    $('#updaterolemodal').modal('hide');
                    location.reload();
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $(document).on('click', '.deleteroledata', function(){
            var jerome = $('input[name="role_id"]').val();

            if(confirm("Are you sure you want to delete this record?")) {
                $.ajax({
                    url: "{{ URL::to('/deleteRole') }}",
                    method: "POST",
                    data:{
                        role_id:jerome,
                        _token: "{{ csrf_token() }}"
                    },
                    success:function(data){
                        location.reload();
                    }
                });
            }
        });
    });
</script>
{{-- End of Role Module --}}

{{-- For User Module --}}
<script>
    $(document).ready(function() {
        $('.editusermodal').click(function() {
            var user_id = $(this).attr('data-userid');

            $.ajax({
                url: "{{ URL::to('/editUser') }}",
                method: "POST",
                data: {
                    user_id: user_id,
                    _token: '{{ csrf_token() }}'
                },
                success: function(data) {
                    $('.updateusercontent').html(data);
                    $('#updateusermodal').modal('show');
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#updateuserdata').click(function() {
            var first_name = $('input[name="first_name"]').val();
            var last_name = $('input[name="last_name"]').val();
            var email = $('input[name="email_address"]').val();
            var role = $('select[name="role"]').val();
            var user_id = $('input[name="user_id"]').val();

            $.ajax({
                url: "{{ URL::to('/updateUser') }}",
                method: "POST",
                data: {
                    user_id: user_id,
                    first_name: first_name,
                    last_name: last_name,
                    email_address: email,
                    description: description,
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {
                    $('#updateusermodal').modal('hide');
                    location.reload();
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $(document).on('click', '.deleteuserdata', function(){
            var user_id = $('input[name="user_id"]').val();

            if(confirm("Are you sure you want to delete this record?")) {
                $.ajax({
                    url: "{{ URL::to('/deleteUser') }}",
                    method: "POST",
                    data:{
                        user_id: user_id,
                        _token: "{{ csrf_token() }}"
                    },
                    success:function(data){
                        location.reload();
                    }
                });
            }
        });
    });
</script>
{{-- End of User Module --}}

{{-- For Expense Category Module --}}
<script>
    $(document).ready(function() {
        $('.edit-category-modal').click(function() {
            var category_id = $(this).attr('data-categoryid');
            $.ajax({
                url: "{{ URL::to('/editExpenseCategory') }}",
                method: "POST",
                data: {
                    category_id: category_id,
                    _token: '{{ csrf_token() }}'
                },
                success: function(data) {
                    $('.update-category-content').html(data);
                    $('#update-category-modal').modal('show');
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#update-category-data').click(function() {
            var category_name = $('input[name="category_name"]').val();
            var category_description = $('input[name="category_description"]').val();
            var category_id = $('input[name="category_id"]').val();

            $.ajax({
                url: "{{ URL::to('/updateExpenseCategory') }}",
                method: "POST",
                data: {
                    category_id: category_id,
                    category_name: category_name,
                    category_description: category_description,
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {
                    $('#update-category-modal').modal('hide');
                    location.reload();
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $(document).on('click', '.delete-category-data', function(){
            var category_id = $('input[name="category_id"]').val();

            if(confirm("Are you sure you want to delete this record?")) {
                $.ajax({
                    url: "{{ URL::to('/deleteExpenseCategory') }}",
                    method: "POST",
                    data:{
                        category_id: category_id,
                        _token: "{{ csrf_token() }}"
                    },
                    success:function(data){
                        location.reload();
                    }
                });
            }
        });
    });
</script>
{{-- End of Expense Category Module --}}

{{-- For Expenses  Module --}}

{{-- for datepicker --}}
<script>
    $(document).ready(function () {
        $("#entry_date_update").datepicker({
            minDate: '+0',
            dateFormat: "yy-mm-dd"
        });
    });
</script>

<script>
    $(document).ready(function () {
        $("#entry_date").datepicker({
            minDate: '+0',
            dateFormat: "yy-mm-dd"
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('.edit-expense-modal').click(function() {
            var expense_id = $(this).attr('data-expenseid');

            $.ajax({
                url: "{{ URL::to('/editExpense') }}",
                method: "POST",
                data: {
                    expense_id: expense_id,
                    _token: '{{ csrf_token() }}'
                },
                success: function(data) {
                    $('.update-expense-content').html(data);
                    $('#update-expense-modal').modal('show');
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#update-expense-data').click(function() {
            var category_name = $('input[name="category_name"]').val();
            var expense_amount = $('input[name="expense_amount"]').val();
            var entry_date = $('input[name="entry_date"]').val();
            var expense_id = $('input[name="expense_id"]').val();

            $.ajax({
                url: "{{ URL::to('/updateExpenseCategory') }}",
                method: "POST",
                data: {
                    expense_id: expense_id,
                    category_name: category_name,
                    category_description: category_description,
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {
                    $('#update-category-modal').modal('hide');
                    location.reload();
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $(document).off('click', '.delete-expense-data').on('click', '.delete-expense-data', function() {
            var expense_id = $('input[name="expense_id"]').val();

            if(confirm("Are you sure you want to delete this record?")) {
                $.ajax({
                    url: "{{ URL::to('/deleteExpense') }}",
                    method: "POST",
                    data:{
                        expense_id: expense_id,
                        _token: "{{ csrf_token() }}"
                    },
                    success:function(data){
                        location.reload();
                    }
                });
            }
        });
    });
</script>
{{-- End of Expenses Module --}}

{{-- for active classes - sidenav --}}
<script>
    $(document).ready(function () {
        var url = window.location.href;

        $('#sidebar-menu a').filter(function () {
            return this.href == url;
        }).addClass('active').parents('.nav-item').addClass('active');

        $('.nav-item.active .nav-treeview .nav-item.active > a > .nav-icon').removeClass('far').addClass('fas');
    });
</script>

{{-- loader --}}
{{-- <script>
    setTimeout(function(){
        $('.loader_bg').fadeToggle();
    }, 1500);
</script> --}}