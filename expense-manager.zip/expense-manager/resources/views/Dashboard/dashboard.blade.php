<!DOCTYPE html>

<html>
    <link rel="stylesheet" href="{{ asset('adminlte/plugins/fontawesome-free/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset('adminlte/dist/css/adminlte.min.css') }}">
    <link rel="stylesheet" href="{{ asset('adminlte/plugins/fontawesome-free/css/all.min.css') }}">
    <script src="{{ asset('adminlte/dist/js/adminlte.min.js') }}"></script>
    <script src="{{ asset('adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('adminlte/plugins/jquery/jquery.min.js') }}"></script>

    @include('common.navbar')

    <body class="hold-transition sidebar-mini sidebar-collapse">
        @include('common.meta')

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

        <div class="content-wrapper content-wrapper-blade">
            <div class="container mt-5">
                <div class="row">
                    <div class="col-7">
                        <div class="card card-dark">
                            <div class="card-header">
                                <h3 class="card-title pt-2"><b>My Expenses</b></h3>
                            </div>
    
                            <div class="card-body">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">Expense Category</th>
                                            <th scope="col">Total Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if (count($expenses) > 0)
                                            @foreach ($expenses as $expense)
                                                <tr>
                                                    <td>
                                                        {{ $expense->expense_category }}
                                                    </td>
                                                    <td>
                                                        {{ $expense->expense_amount }}
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-5">
                        <div class="card card-danger">
                            <div class="card-header">
                                <h3 class="card-title pt-2"><b>Pie Chart</b></h3>
                            </div>
                            
                            <div class="card-body">
                                <canvas id="pieChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Pie chart --}}
<script>
    $(document).ready(function () {
        // var pieData = {
        //     datasets: [{
        //         data: [40, 60],
        //         backgroundColor: ['#000', '#ffce56']
        //     }],
        //     labels: ['Black', 'Yellow']
        // };

        // var pieOptions = {
        //     maintainAspectRatio: false,
        //     responsive: true,
        // };

        // var pieChartCanvas = $('#pieChart').get(0).getContext('2d');
        // new Chart(pieChartCanvas, {
        //     type: 'pie',
        //     data: pieData,
        //     options: pieOptions
        // });
        // Get the data from the table
        var categories = [];
        var amounts = [];
        @foreach ($expenses as $expense)
            categories.push("{{ $expense->expense_category }}");
            amounts.push({{ $expense->expense_amount }});
        @endforeach
        
        // Generate the pie chart data
        var pieData = {
            datasets: [{
                data: amounts,
                backgroundColor: [
                    '#F7464A',
                    '#46BFBD',
                    '#FDB45C',
                    '#949FB1',
                    '#4D5360',
                    '#AC64AD',
                    '#FF9F40',
                    '#3E95CD',
                    '#D2B4DE',
                    '#85C1E9',
                ].slice(0, amounts.length)
            }],
            labels: categories
        };

        var pieOptions = {
            maintainAspectRatio: false,
            responsive: true,
        };

        var pieChartCanvas = $('#pieChart').get(0).getContext('2d');
        new Chart(pieChartCanvas, {
            type: 'pie',
            data: pieData,
            options: pieOptions
        });
    })
</script>

        @include('scripts.scripts')
    </body>
</html>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
