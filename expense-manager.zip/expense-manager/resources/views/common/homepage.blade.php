<!DOCTYPE html>

<html>
	@include('common.meta')

<body class="hold-transition sidebar-mini sidebar-collapse">
	@include('scripts.scripts')
    
    @if (Auth::guard('customer')->check() == false)
        @include('common.landing_page')
    @endif

    {{-- @stack('newscripts') --}}
    <!-- ./end of js scripts -->

	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K2RGBLR"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->
</body>

</html>

