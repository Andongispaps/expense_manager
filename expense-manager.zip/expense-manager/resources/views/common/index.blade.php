@extends('layout')
@section('content')
    {{-- <section class="sites-content text-center mt-5">
        @include('common.login')
    </section> --}}

    <section class="sites-content text-center mt-5">
        @include('common.homepage')
    </section>

    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons.css">
@endsection