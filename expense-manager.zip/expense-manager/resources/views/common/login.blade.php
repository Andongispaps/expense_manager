
@include('common.meta')

	<div class="container d-flex justify-content-center">
		<div class="col-lg-3">
			@if (session('success'))
				<div class="alert alert-success">
					{{ session('success') }}
				</div>
			@endif
		</div>
	</div>
	<div class="card">
		<div class="login-box">
			<div class="card card-outline card-primary">
				<div class="card-header text-center">
					<a href="" class="login-header-text h3"><b>Login</b></a>
				</div>
				@if(Session::has('loginError'))
					<div class="alert alert-danger alert-dismissible fade show" role="alert">
						<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
						<span class="sr-only">@lang('website.Error'):</span>
						{!! session('loginError') !!}
	
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
				@endif
				<div class="card-body">
					<p class="login-box-msg">Sign in to start your session</p>
			
					<form name="signup" enctype="multipart/form-data" class="form-validate"  action="{{ URL::to('/process-login')}}" method="post">
						@csrf
						<div class="input-group mb-3">
							<input type="text" class="form-control" id="email" name="username" aria-describedby="emailHelp" required="true" placeholder="Username">
							<div class="input-group-append">
								<div class="input-group-text">
									<span class="fas fa-envelope"></span>
								</div>
							</div>
						</div>
						<div class="input-group mb-3">
							<input name="password" type="password" class="input form-control field-validate" id="password" required="true" aria-label="password" aria-describedby="basic-addon1" required="true" placeholder="Password">
							<div class="input-group-append">
								<div class="input-group-text">
									<span class="fas fa-lock"></span>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-12 text-center">
								<button type="submit" class="btn btn-primary btn-block">Login</button>
							</div>
						</div>
					</form>

					<div class="row">
						<div class="col-12">
							<a type="button" href="{{ URL::to('/')}}" class="btn btn-danger btn-block">Cancel</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<body class="hold-transition login-page">

</body>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
