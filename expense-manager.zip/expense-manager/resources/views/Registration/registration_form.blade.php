
@include('common.meta')

	<div class="container">
		<div class="col-lg-12 d-flex justify-content-center mt-5 pt-5">
			<div class="register-box">
				<div class="card card-outline card-primary">
					<div class="card-header text-center">
						<a href="" class="h1 registration-form-text"><b>Expense</b>Manager</a>
					</div>
					<div class="card-body">
						<p class="login-box-msg">Register for a new membership</p>
		
						@if(Session::has('loginError'))
							<div class="alert alert-danger alert-dismissible fade show" role="alert">
								<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
								<span class="sr-only">@lang('website.Error'):</span>
								{!! session('loginError') !!}
		
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
						@endif
				
						<form name="signup" enctype="multipart/form-data" class="form-validate"  action="{{ URL::to('/registerAcc')}}" method="post">
							@csrf
							<div class="input-group mb-3">
								<input type="text" class="form-control" placeholder="First name" name="first_name">
								<div class="input-group-append">
									<div class="input-group-text">
										<span class="fas fa-user"></span>
									</div>
								</div>
							</div>
							<div class="input-group mb-3">
								<input type="text" class="form-control" placeholder="Last name" name="last_name">
								<div class="input-group-append">
									<div class="input-group-text">
										<span class="fas fa-user"></span>
									</div>
								</div>
							</div>
							<div class="input-group mb-3">
								<input type="text" class="form-control" id="email" name="username" aria-describedby="emailHelp" required="true" placeholder="Username">
								<div class="input-group-append">
									<div class="input-group-text">
										<span class="fas fa-envelope"></span>
									</div>
								</div>
							</div>
							<div class="input-group mb-3">
								<input name="password" type="password" class="input form-control field-validate" id="password" required="true" aria-label="password" aria-describedby="basic-addon1" required="true" placeholder="Password">
								<div class="input-group-append">
									<div class="input-group-text">
										<span class="fas fa-lock"></span>
									</div>
								</div>
							</div>
		
							<div class="col-12">
								<label for="role">Role:</label>
							</div>
		
							<select name="role" id="role" class="form-select mb-3">
								<option value="1">Admin</option>
								<option value="0">User</option>
							</select>
		
							<div class="row">
								<div class="col-12">
									<button type="submit" class="btn btn-primary btn-block">Register</button>
								</div>
							</div>
						</form>
						
						<div class="row">
							<div class="col-12">
								<a type="button" href="{{ URL::to('/login')}}" class="btn btn-danger btn-block">Cancel</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
