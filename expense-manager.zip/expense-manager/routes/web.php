<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('common.index');
});

Route::group(['namespace' => 'Web'], function () {
    // Route::get('/', 'DefaultController@index');
    // Route::get('/index', 'DefaultController@index');

    // Login
    Route::get('/login', 'UserController@login');
    Route::post('/process-login', 'UserController@processLogin');
    Route::get('/logout', 'UserController@logout');

    // Role Module
    Route::get('/roles', 'RolesController@roles');
    Route::post('/addNewRole', 'RolesController@addnewrole');
    Route::post('editRole', 'RolesController@editrole');
    Route::post('updateRole', 'RolesController@updaterole');
    Route::post('/deleteRole', 'RolesController@deleterole');

    // User Module
    Route::get('/users', 'UsersController@users');
    Route::post('/addNewUser', 'UsersController@addnewuser');
    Route::post('editUser', 'UsersController@edituser');
    Route::post('updateUser', 'UsersController@updateuser');
    Route::post('/deleteUser', 'UsersController@deleteuser');

    // Expense Category Module
    Route::get('/expenseCategories', 'ExpenseCategoriesController@expenseCategories');
    Route::post('/addNewExpenseCategory', 'ExpenseCategoriesController@addNewExpenseCategory');
    Route::post('/editExpenseCategory', 'ExpenseCategoriesController@editExpenseCategory');
    Route::post('updateExpenseCategory', 'ExpenseCategoriesController@updateExpenseCategory');
    Route::post('/deleteExpenseCategory', 'ExpenseCategoriesController@deleteExpenseCategory');

    // Expenses Module
    Route::get('/expenses', 'ExpensesController@expenses');
    Route::post('/addNewExpense', 'ExpensesController@addNewExpense');
    Route::post('/editExpense', 'ExpensesController@editExpense');
    Route::post('updateExpense', 'ExpensesController@updateExpense');
    Route::post('/deleteExpense', 'ExpensesController@deleteExpense');

    // Dashboard
    Route::get('/expensesData', 'DashboardController@expensesData');

    // Register
    Route::post('/registerAcc', 'RegistrationController@registerAcc');
    Route::get('/registrationForm', 'RegistrationController@registrationForm');
});