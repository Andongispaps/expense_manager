<?php $__env->startSection('content'); ?>
    

    <section class="sites-content text-center mt-5">
        <?php echo $__env->make('common.homepage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>

    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\expense-mng\resources\views/common/index.blade.php ENDPATH**/ ?>