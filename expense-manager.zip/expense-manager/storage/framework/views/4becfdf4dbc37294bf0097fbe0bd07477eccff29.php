<?php echo Form::open(array('url' =>'updateUser', 'method'=>'post', 'class' => 'form-horizontal', 'enctype'=>'multipart/form-data')); ?>

    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit User Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    
    <div class="modal-body">
        <input type="hidden" name="user_id" value="<?php echo e($users[0]->user_id); ?>">

        <div class="row align-items-center mb-3">
            <div class="col-4">
                <label for="name">First Name:</label>
            </div>
            <div class="col-8">
                <input type="text" name="first_name" class="form-control" value="<?php echo e($users[0]->first_name); ?>" required="true">
            </div>
        </div>

        <div class="row align-items-center mb-3">
            <div class="col-4">
                <label for="name">Last Name:</label>
            </div>
            <div class="col-8">
                <input type="text" name="last_name" class="form-control" value="<?php echo e($users[0]->last_name); ?>" required="true">
            </div>
        </div>

        <div class="row align-items-center mt-3">
            <div class="col-4">
                <label for="description">Description:</label>
            </div>
            <div class="col-8">
                <input type="email" name="email_address" class="form-control" value="<?php echo e($users[0]->email_address); ?>" required="true">
            </div>
        </div>

        <div class="row align-items-center mt-3">
            <div class="col-4">
                <label for="description">Roles:</label>
            </div>
            <div class="col-8">
                <select name="role" id="role" class="form-control">
                    <option value="1" <?php if($users[0]->role == '1'): ?> selected <?php endif; ?>>Admin</option>
                    <option value="0" <?php if($users[0]->role == '0'): ?> selected <?php endif; ?>>User</option>
                </select>
            </div>
        </div>
    </div>
    
    <div class="modal-footer">
        <div class="col-lg-2 text-start">
            <button type="button" class="btn btn-danger deleteuserdata" id="deleteuserdata">Delete</button>
        </div>
        <div class="col-lg-9 text-end">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary updateuserdata" id="updateuserdata">Save changes</button>
        </div>
    </div>

<?php echo Form::close(); ?>


<?php echo $__env->make('scripts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<?php /**PATH C:\laragon\www\expense-mng\resources\views/users/updateusermodal.blade.php ENDPATH**/ ?>