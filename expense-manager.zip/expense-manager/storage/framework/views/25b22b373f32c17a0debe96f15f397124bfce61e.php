<?php echo Form::open(array('url' =>'updateExpenseCategory', 'name'=>'editImageFrom', 'id'=>'editImageFrom', 'method'=>'post', 'class' => 'form-horizontal', 'enctype'=>'multipart/form-data')); ?>

    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Expense Category</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <input type="hidden" name="category_id" value="<?php echo e($categories[0]->category_id); ?>">
        <div class="row align-items-center mb-3">
            <div class="col-4">
                <label for="name">Display Name:</label>
            </div>
            <div class="col-8">
                <input type="text" name="category_name" class="form-control" value="<?php echo e($categories[0]->category_name); ?>" required="true">
            </div>
        </div>
        <div class="row align-items-center mt-3">
            <div class="col-4">
                <label for="description">Description:</label>
            </div>
            <div class="col-8">
                <input type="text" name="category_description" class="form-control" value="<?php echo e($categories[0]->category_description); ?>" required="true">
            </div>
        </div>
    </div>

    <div class="modal-footer">
        <div class="col-lg-2 text-start">
            <button type="button" class="btn btn-danger delete-category-data" id="delete-category-data">Delete</button>
        </div>
        <div class="col-lg-9 text-end">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary update-category-data" id="update-category-data">Save changes</button>
        </div>
    </div>
<?php echo Form::close(); ?>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<?php /**PATH C:\laragon\www\expense-mng\resources\views/categories/update_category_modal.blade.php ENDPATH**/ ?>