<?php echo $__env->make('common.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="form-portal">
    <p class="portal-description"></p>
    <div class="portal-panel">
        <form class="portal-form pt-3">
            <p class="portal-panel-description">Hi, User!</p>
            <p class="portal-destination">
                Please click or tap your destination.
            </p>
            <a class="btn btn-primary student-btn pt-2" href="<?php echo e(URL::to('/login')); ?>" type="button" id="btn-login" >Login</a>

            <a class="btn btn-primary faculty-btn pt-2" href="<?php echo e(URL::to('/registrationForm')); ?>" type="button" id="btn-register" >Register</a>
        </form>
    </div>
</main><?php /**PATH C:\laragon\www\expense-mng\resources\views/common/landing_page.blade.php ENDPATH**/ ?>