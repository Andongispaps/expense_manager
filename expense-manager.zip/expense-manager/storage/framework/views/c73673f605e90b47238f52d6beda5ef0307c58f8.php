<!DOCTYPE html>

<html>
    <link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('adminlte/dist/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/fontawesome-free/css/all.min.css')); ?>">
    <script src="<?php echo e(asset('adminlte/dist/js/adminlte.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminlte/plugins/jquery/jquery.min.js')); ?>"></script>

    <?php echo $__env->make('common.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body class="hold-transition sidebar-mini sidebar-collapse">
        <?php echo $__env->make('common.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

        <div class="content-wrapper content-wrapper-blade">
            <div class="container mt-5">
                <div class="row">
                    <div class="col-7">
                        <div class="card card-dark">
                            <div class="card-header">
                                <h3 class="card-title pt-2"><b>My Expenses</b></h3>
                            </div>
    
                            <div class="card-body">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">Expense Category</th>
                                            <th scope="col">Total Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($expenses) > 0): ?>
                                            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($expense->expense_category); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($expense->expense_amount); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-5">
                        <div class="card card-danger">
                            <div class="card-header">
                                <h3 class="card-title pt-2"><b>Pie Chart</b></h3>
                            </div>
                            
                            <div class="card-body">
                                <canvas id="pieChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
<script>
    $(document).ready(function () {
        // var pieData = {
        //     datasets: [{
        //         data: [40, 60],
        //         backgroundColor: ['#000', '#ffce56']
        //     }],
        //     labels: ['Black', 'Yellow']
        // };

        // var pieOptions = {
        //     maintainAspectRatio: false,
        //     responsive: true,
        // };

        // var pieChartCanvas = $('#pieChart').get(0).getContext('2d');
        // new Chart(pieChartCanvas, {
        //     type: 'pie',
        //     data: pieData,
        //     options: pieOptions
        // });
        // Get the data from the table
        var categories = [];
        var amounts = [];
        <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            categories.push("<?php echo e($expense->expense_category); ?>");
            amounts.push(<?php echo e($expense->expense_amount); ?>);
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        // Generate the pie chart data
        var pieData = {
            datasets: [{
                data: amounts,
                backgroundColor: [
                    '#F7464A',
                    '#46BFBD',
                    '#FDB45C',
                    '#949FB1',
                    '#4D5360',
                    '#AC64AD',
                    '#FF9F40',
                    '#3E95CD',
                    '#D2B4DE',
                    '#85C1E9',
                ].slice(0, amounts.length)
            }],
            labels: categories
        };

        var pieOptions = {
            maintainAspectRatio: false,
            responsive: true,
        };

        var pieChartCanvas = $('#pieChart').get(0).getContext('2d');
        new Chart(pieChartCanvas, {
            type: 'pie',
            data: pieData,
            options: pieOptions
        });
    })
</script>

        <?php echo $__env->make('scripts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<?php /**PATH C:\laragon\www\expense-mng\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>