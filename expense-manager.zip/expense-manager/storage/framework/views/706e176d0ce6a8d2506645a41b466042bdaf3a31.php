<?php echo Form::open(array('url' =>'updateExpense', 'name'=>'editImageFrom', 'id'=>'editImageFrom', 'method'=>'post', 'class' => 'form-horizontal', 'enctype'=>'multipart/form-data')); ?>

    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Expense Category</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>

    <div class="modal-body">
        <input type="hidden" name="expense_id" value="<?php echo e($expenses[0]->expense_id); ?>">
        <div class="row align-items-center mt-3">
            <div class="col-4">
                <label for="description">Expense Category:</label>
            </div>
            <div class="col-8">
                <select name="category_name" id="category_name" class="form-control">
                    <?php if(count($exp_categories) > 0): ?>
                        <?php $__currentLoopData = $exp_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($exp_category->category_name); ?>"><?php echo e($exp_category->category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
        </div>

        <div class="row align-items-center mt-3">
            <div class="col-4">
                <label for="description">Amount:</label>
            </div>
            <div class="col-8">
                <input type="number" name="expense_amount" class="form-control" value="<?php echo e($expenses[0]->expense_amount); ?>" step="any" required="true">
            </div>
        </div>

        <div class="row align-items-center mt-3">
            <div class="col-4">
                <label for="name">Entry Date:</label>
            </div>
            <div class="col-8">
                <input type="text" name="entry_date" class="form-control" id="entry_date_update" autocomplete="off" value="<?php echo e($expenses[0]->entry_date); ?>" required="true">
            </div>
        </div>
    </div>

    <div class="modal-footer">
        <div class="col-lg-2 text-start">
            <button type="button" class="btn btn-danger delete-expense-data" id="delete-expense-data">Delete</button>
        </div>
        <div class="col-lg-9 text-end">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary update-expense-data" id="update-expense-data">Save changes</button>
        </div>
    </div>
<?php echo Form::close(); ?>


<?php echo $__env->make('scripts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<?php /**PATH C:\laragon\www\expense-mng\resources\views/expenses/update_expense_modal.blade.php ENDPATH**/ ?>