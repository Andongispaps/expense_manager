/*
SQLyog Community v13.2.0 (64 bit)
MySQL - 5.7.33 : Database - expense_manager
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`expense_manager` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `expense_manager`;

/*Table structure for table `expense_categories` */

DROP TABLE IF EXISTS `expense_categories`;

CREATE TABLE `expense_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `category_description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `expense_categories` */

insert  into `expense_categories`(`category_id`,`category_name`,`category_description`,`created_at`,`updated_at`) values 
(1,'Travel','Transportation','2023-04-28 14:48:22','2023-04-28 14:48:22'),
(6,'PC Parts','RTX 3080 12 Gb OC-Edition','2023-04-28 07:44:36','2023-04-28 15:44:36'),
(7,'Foods','Breakfast-Lunch-Dinner','2023-04-28 11:28:55','2023-04-28 04:11:42'),
(9,'Instruments','Drum sticks and Cymbals','2023-04-29 04:44:42','2023-04-29 12:44:42'),
(10,'Foot Wear','Shoes','2023-04-29 04:46:44','2023-04-29 12:46:44'),
(11,'Gems','Minecraft','2023-04-29 04:47:20','2023-04-29 12:47:20');

/*Table structure for table `expenses` */

DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `expense_id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_category` varchar(255) NOT NULL,
  `expense_amount` decimal(10,2) NOT NULL,
  `entry_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `expenses` */

insert  into `expenses`(`expense_id`,`expense_category`,`expense_amount`,`entry_date`,`created_at`,`updated_at`) values 
(1,'PC Parts',3400.00,'2023-06-30','2023-04-28 15:31:13','2023-04-28 08:40:32'),
(4,'Travel',8765.00,'2023-04-28','2023-04-28 11:50:52','2023-04-29 04:35:21'),
(8,'Foods',5000.00,'2023-04-29','2023-04-28 04:11:54','2023-04-29 04:36:50'),
(9,'Foot Wear',5000.00,'2023-04-29','2023-04-29 04:48:22','2023-04-29 12:48:22'),
(10,'Instruments',10000.00,'2023-04-30','2023-04-29 04:48:36','2023-04-29 12:48:36');

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `migrations` */

/*Table structure for table `roles` */

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `display_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `role` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `roles` */

insert  into `roles`(`role_id`,`display_name`,`description`,`role`,`created_at`,`updated_at`) values 
(1,'Administrator','Super User',1,'2023-04-26 21:27:24','2023-04-28 04:11:24'),
(2,'User','Adds Expenses',0,'2023-04-26 21:27:38','2023-04-28 11:11:09'),
(11,'Viewer','Can only view',0,'2023-04-28 11:14:42','2023-04-28 04:08:45');

/*Table structure for table `user_accounts` */

DROP TABLE IF EXISTS `user_accounts`;

CREATE TABLE `user_accounts` (
  `acc_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` tinyint(1) NOT NULL DEFAULT '1',
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`acc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `user_accounts` */

insert  into `user_accounts`(`acc_id`,`username`,`password`,`role`,`first_name`,`last_name`,`created_at`,`updated_at`) values 
(1,'admin','$2a$12$EO5ZV7Tvm7hFwuKnAFssxeQXRUqpykmHXgsc96x2WAhnyhuUBr3ui',1,'Al Jhune','Alcober','2023-04-26 13:43:44','2023-04-26 13:43:44'),
(6,'NinaMC','$2y$10$noXCgdErl4UW1c..UvN.D.rrrrVaG93UVFvQXSf/B/Uhe3aKw3Cme',0,'Nina','Surname','2023-04-29 05:26:36','2023-04-29 13:26:36');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `role` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`user_id`,`first_name`,`last_name`,`email_address`,`role`,`created_at`,`updated_at`) values 
(1,'Jerome','Salle','jerome@gmail.com',1,'2023-04-28 11:04:41','2023-04-28 04:11:19');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
