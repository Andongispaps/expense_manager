<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Customer extends Authenticatable
{
	protected $guard = 'customers';
	protected $table = 'user_accounts';
    protected $fillable = ['acc_id', 'acc_username', 'acc_password', 'user_type', 'created_at' , 'updated_at'];
    protected $hidden = ['acc_password', 'remember_token'];
	protected $primaryKey = 'acc_id';
	
    public static function new()
    {
        return self::where('is_seen',0)
            ->orderBy('acc_id','DESC')
            ->get();
    }
}
