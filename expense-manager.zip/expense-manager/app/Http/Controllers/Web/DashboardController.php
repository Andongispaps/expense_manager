<?php
/*
Project Name: SpeedRegalo
Project URI: https://www.speedregalo.com.ph
Author: SpeedRegalo Team
Author URI: https://www.speedregalo.com.ph
*/
namespace App\Http\Controllers\Web;
use App\User;
use Socialite;
//use Mail;
//validator is builtin class in laravel
use Validator;
use Services;
use File; 

use Illuminate\Contracts\Auth\Authenticatable;
use Hash;
use DB;


//for authenitcate login data
use Auth;
use Illuminate\Foundation\Auth\ThrottlesLogins;


//for requesting a value 
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
//for Carbon a value 
use Carbon;
use Illuminate\Support\Facades\Redirect;
use Session;
use Lang;

//email
use Illuminate\Support\Facades\Mail;

class DashboardController extends Controller
{
	
    /**
     * Create a new controller instance.
     *
     * @return void
     */
  
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
     // Expense category page
    //  public function expensesData(Request $request) {
    //     $expenses = DB::table('expenses')->get();
    
    //     return view('common.homepage', ['expenses' => $expenses])
    //            ->with('expenses', $expenses);
    // }

    public function expensesData(Request $request) {
        // $expenses = DB::table('expense_categories')
        //     ->leftJoin('expenses' , 'expenses.expense_category' , '=' , 'expense_categories.category_name')
        //     ->get();
        $expenses = DB::table('expenses')->get();
        
        return view("dashboard.dashboard")->with('expenses', $expenses);
    }
}
