<?php
/*
Project Name: SpeedRegalo
Project URI: https://www.speedregalo.com.ph
Author: SpeedRegalo Team
Author URI: https://www.speedregalo.com.ph
*/
namespace App\Http\Controllers\Web;
use App\User;
use Socialite;
//use Mail;
//validator is builtin class in laravel
use Validator;
use Services;
use File; 

use Illuminate\Contracts\Auth\Authenticatable;
use Hash;
use DB;


//for authenitcate login data
use Auth;
use Illuminate\Foundation\Auth\ThrottlesLogins;


//for requesting a value 
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
//for Carbon a value 
use Carbon;
use Illuminate\Support\Facades\Redirect;
use Session;
use Lang;

//email
use Illuminate\Support\Facades\Mail;

class UserController extends Controller
{
	
    /**
     * Create a new controller instance.
     *
     * @return void
     */
  
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request) {
        if(auth()->guard('customer')->check()){
			return redirect('/');
		}
		else{
			$result = array();
            $result['test'] = DB::table('user_accounts')->get();				
			return view("common.login")->with('result', $result);   
		} 		
    }

    public function processLogin(Request $request) {
        $result = array();
        $message = "Mali man, bobo mo naman";
        $customerInfo = array("username" => $request->username, "password" => $request->password);
        
        if(auth()->guard('customer')->attempt($customerInfo)) {
			return redirect()->intended('/')->with('result', $result);
        } else {
            return redirect()->back()->with('loginError' , $message);
        }
    }

    public function logout(Request $request){
		Auth::logout();
		Auth::guard('customer')->logout();

		session()->flush();

		$request->session()->forget('acc_id');
		$request->session()->regenerate();		

		return redirect('/login');
	}
}
