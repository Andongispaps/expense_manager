<?php
/*
Project Name: SpeedRegalo
Project URI: https://www.speedregalo.com.ph
Author: SpeedRegalo Team
Author URI: https://www.speedregalo.com.ph
*/
namespace App\Http\Controllers\Web;
use App\User;
use Socialite;
//use Mail;
//validator is builtin class in laravel
use Validator;
use Services;
use File; 

use Illuminate\Contracts\Auth\Authenticatable;
use Hash;
use DB;


//for authenitcate login data
use Auth;
use Illuminate\Foundation\Auth\ThrottlesLogins;


//for requesting a value 
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
//for Carbon a value 
use Carbon;
use Illuminate\Support\Facades\Redirect;
use Session;
use Lang;

//email
use Illuminate\Support\Facades\Mail;

class RolesController extends Controller
{
	
    /**
     * Create a new controller instance.
     *
     * @return void
     */
  
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    // Roles page
    public function roles(Request $request) {
        $roles = DB::table('roles')->get();

        return view("roles.roles")->with('roles', $roles);   
    }

    public function addNewRole(Request $request) {
        $name = $request->input('name');
        $description = $request->input('description');
		$created_at = date('y-m-d h:i:s');

        $validator = Validator::make($request->all(), [
            'name' => 'required|max:30|regex: /^[a-zA-Z\s\.]+$/',
            'description' => 'required|max:40|regex: /^[a-zA-Z\s\.\-,]+$/',
        ]);
        
        if ($validator->fails()) {
			return redirect('roles')->withErrors($validator);
		} else {
            DB::table('roles')->insert([
                'display_name' => $name,
                'description' => $description,
                'created_at' => $created_at,
            ]);
        }
        
        return redirect()->back();
    }

    // landing page for edit/update
	public function editRole(Request $request) {
		$roles = DB::table('roles')->where('roles.role_id', '=' , $request->role_id)->get();

		return view("roles.updaterolemodal")->with('roles', $roles);
	}

    // Update role details
    public function updateRole(Request $request) {
        $updated_at = date('y-m-d h:i:s');

        $validator = Validator::make($request->all(), [
            'name' => 'required|max:30|regex: /^[a-zA-Z\s\.]+$/',
            'description' => 'required|max:40|regex: /^[a-zA-Z\s\.\-,]+$/',
        ]);
        
        if ($validator->fails()) {
            return redirect('roles')->withErrors($validator);
        } else {
            DB::table('roles')->where('roles.role_id' , '=' , $request->role_id)
            ->update([
                'display_name' => $request->name,
                'description' => $request->description,
                'updated_at' => $updated_at
            ]);
        }
        
        $updated_role_data = DB::table('roles')->where('roles.role_id', '=' , $request->role_id)->get();

        return redirect()->back();
    }

    // Delete role entry
    public function deleteRole(Request $request) {
        $updated_role_data = DB::table('roles')->where('roles.role_id', '=' , $request->role_id)->delete();

        return redirect()->back();
    }
}
