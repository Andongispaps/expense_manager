<?php
/*
Project Name: SpeedRegalo
Project URI: https://www.speedregalo.com.ph
Author: SpeedRegalo Team
Author URI: https://www.speedregalo.com.ph
*/
namespace App\Http\Controllers\Web;
use App\User;
use Socialite;
//use Mail;
//validator is builtin class in laravel
use Validator;
use Services;
use File; 

use Illuminate\Contracts\Auth\Authenticatable;
use Hash;
use DB;


//for authenitcate login data
use Auth;
use Illuminate\Foundation\Auth\ThrottlesLogins;


//for requesting a value 
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
//for Carbon a value 
use Carbon;
use Illuminate\Support\Facades\Redirect;
use Session;
use Lang;

//email
use Illuminate\Support\Facades\Mail;

class RegistrationController extends Controller
{
	
    /**
     * Create a new controller instance.
     *
     * @return void
     */
  
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    // Users page
    public function registrationForm(Request $request) {

        return view("registration.registration_form");
    }

    // Add a new user
    public function registerAcc(Request $request) {
        $first_name = $request->input('first_name');
        $last_name = $request->input('last_name');
        $username = $request->input('username');
        $password = Hash::make($request->input('password'));
        $role = $request->input('role');
		$created_at = date('y-m-d h:i:s');

        $validator = Validator::make($request->all(), [
            'first_name' => 'required|max: 30|regex:/^[a-zA-Z\s\.]+$/',
            'last_name' => 'required|max: 30|regex:/^[a-zA-Z\s\.]+$/',
            'username' => 'required|max: 30|regex:/^[a-zA-Z\s\.]+$/',
            'password' => 'required|max: 30|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/',
        ]);
        
        if ($validator->fails()) {
			return redirect('registration_form')->withErrors($validator);
		} else {
            DB::table('user_accounts')->insert([
                'first_name' => $first_name,
                'last_name' => $last_name,
                'username' => $username,
                'password' => $password,
                'role' => $role,
                'created_at' => $created_at,
            ]);
        }
        
        return redirect('/login')->with('success', 'Your account has been created successfully!');;
    }
}
