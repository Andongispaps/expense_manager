<?php
/*
Project Name: SpeedRegalo
Project URI: https://www.speedregalo.com.ph
Author: SpeedRegalo Team
Author URI: https://www.speedregalo.com.ph
*/
namespace App\Http\Controllers\Web;
use App\User;
use Socialite;
//use Mail;
//validator is builtin class in laravel
use Validator;
use Services;
use File; 

use Illuminate\Contracts\Auth\Authenticatable;
use Hash;
use DB;


//for authenitcate login data
use Auth;
use Illuminate\Foundation\Auth\ThrottlesLogins;


//for requesting a value 
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
//for Carbon a value 
use Carbon;
use Illuminate\Support\Facades\Redirect;
use Session;
use Lang;

//email
use Illuminate\Support\Facades\Mail;

class ExpensesController extends Controller
{
	
    /**
     * Create a new controller instance.
     *
     * @return void
     */
  
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    // Expenses landing page
    public function expenses(Request $request) {
        $expenses = DB::table('expenses')->get();
        $exp_categories = DB::table('expense_categories')->get();

        return view("expenses.expenses", compact('expenses', 'exp_categories'));
    }

    // Add a new expense
    public function addNewExpense(Request $request) {
        $category_name = $request->input('category_name');
        $expense_amount = $request->input('expense_amount');
        $entry_date = $request->input('entry_date');
        $created_at = date('y-m-d h:i:s');

        $validator = Validator::make($request->all(), [
            'category_name' => 'required|max:30|regex: /^[a-zA-Z\s\.\-,]+$/',
            'expense_amount' => 'required',
            'entry_date' => 'required',
        ]);
        
        if ($validator->fails()) {
            return redirect('expenses')->withErrors($validator);
        } else {
            DB::table('expenses')->insert([
                'expense_category' => $category_name,
                'expense_amount' => $expense_amount,
                'entry_date' => $entry_date,
                'created_at' => $created_at,
            ]);
        }
        
        return redirect()->back();
    }

    //landing page for edit/update
    public function editExpense(Request $request) {
        $expenses = DB::table('expenses')->where('expenses.expense_id', '=' , $request->expense_id)->get();
        $exp_categories = DB::table('expense_categories')->get();

        return view("expenses.update_expense_modal", compact('expenses', 'exp_categories'));
    }

    public function updateExpense(Request $request) {
        $updated_at = date('y-m-d h:i:s');

        $validator = Validator::make($request->all(), [
            'category_name' => 'required|max:30|regex: /^[a-zA-Z\s\.\-,]+$/',
            'expense_amount' => 'required',
            'entry_date' => 'required',
        ]);
        
        if ($validator->fails()) {
            return redirect('expenses')->withErrors($validator);
        } else {
            DB::table('expenses')->where('expenses.expense_id' , '=' , $request->expense_id)
                ->update([
                    'expense_category' => $request->category_name,
                    'expense_amount' => $request->expense_amount,
                    'entry_date' => $request->entry_date,
                    'updated_at' => $updated_at
                ]);
        }
        
        return redirect()->back();
    }

    public function deleteExpense(Request $request) {
        DB::table('expenses')->where('expenses.expense_id' , '=' , $request->expense_id)->delete();

        return redirect()->back();
    }
}
