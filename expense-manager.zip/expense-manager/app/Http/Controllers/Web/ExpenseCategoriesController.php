<?php
/*
Project Name: SpeedRegalo
Project URI: https://www.speedregalo.com.ph
Author: SpeedRegalo Team
Author URI: https://www.speedregalo.com.ph
*/
namespace App\Http\Controllers\Web;
use App\User;
use Socialite;
//use Mail;
//validator is builtin class in laravel
use Validator;
use Services;
use File; 

use Illuminate\Contracts\Auth\Authenticatable;
use Hash;
use DB;


//for authenitcate login data
use Auth;
use Illuminate\Foundation\Auth\ThrottlesLogins;


//for requesting a value 
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
//for Carbon a value 
use Carbon;
use Illuminate\Support\Facades\Redirect;
use Session;
use Lang;

//email
use Illuminate\Support\Facades\Mail;

class ExpenseCategoriesController extends Controller
{
	
    /**
     * Create a new controller instance.
     *
     * @return void
     */
  
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
     // Expense category page
     public function expenseCategories(Request $request) {
        $exp_categories = DB::table('expense_categories')->get();

        return view("categories.expense_categories")->with('categories' , $exp_categories);
    }

    // Add a new expense category
    public function addNewExpenseCategory(Request $request) {
        $category_name = $request->input('category_name');
        $category_description = $request->input('category_description');
		$created_at = date('y-m-d h:i:s');

        $validator = Validator::make($request->all(), [
            'category_name' => 'required|max:30|regex: /^[a-zA-Z\s\.\-,]+$/',
            'category_description' => 'required|max:40|regex: /^[a-zA-Z\s\.\-,]+$/',
        ]);
        
        if ($validator->fails()) {
			return redirect('expense_categories')->withErrors($validator);
		} else {
            DB::table('expense_categories')->insert([
                'category_name' => $category_name,
                'category_description' => $category_description,
                'created_at' => $created_at,
            ]);
        }
        
        return redirect()->back();
    }

    // landing page for edit/update
	public function editExpenseCategory(Request $request) {
		$exp_categories = DB::table('expense_categories')->where('expense_categories.category_id', '=' , $request->category_id)->get();

		return view("categories.update_category_modal")->with('categories', $exp_categories);
	}

    // Update expense category detail
    public function updateExpenseCategory(Request $request) {
        $updated_at = date('y-m-d h:i:s');

        $validator = Validator::make($request->all(), [
            'category_name' => 'required|max:30|regex: /^[a-zA-Z\s\.\-,]+$/',
            'category_description' => 'required|max:40|regex: /^[a-zA-Z\s\.\-,]+$/',
        ]);
        
        if ($validator->fails()) {
            return redirect('roles')->withErrors($validator);
        } else {
            DB::table('expense_categories')->where('expense_categories.category_id' , '=' , $request->category_id)
            ->update([
                'category_name' => $request->category_name,
                'category_description' => $request->category_description,
                'updated_at' => $updated_at
            ]);
        }
        
        return redirect()->back();
    }

    // Delete expense category entry
    public function deleteExpenseCategory(Request $request) {
        DB::table('expense_categories')->where('expense_categories.category_id' , '=' , $request->category_id)->delete();

        return redirect()->back();
    }
}
